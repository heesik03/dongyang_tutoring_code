package com.dongyang;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PostDAO {
    // 기존 JdbcConnectUtil로 연결하고 연결 실패 확인
    private Connection connect() throws SQLException {
        // 1. 기존 util로 DB 연결 (연결 실패 시 null을 반환하므로 확인)
        Connection con = JdbcConnectUtil.getConnection();
        if (con == null) {
            throw new SQLException("DB 연결에 실패했습니다.");
        }
        return con;
    }

    // 전체 게시글을 최신 번호 순서로 조회
    public ArrayList<PostDTO> findAll() throws SQLException {
        ArrayList<PostDTO> list = new ArrayList<>();
        String sql = "SELECT id, title, content, author FROM post ORDER BY id DESC";
        Connection con = connect();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            // SQL 준비
            pstmt = con.prepareStatement(sql);
            // SELECT는 executeQuery(), 결과는 ResultSet
            rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(toDTO(rs));
            }
        } finally {
            close(con, pstmt, rs);
        }
        return list;
    }

    // 번호로 게시글 한 건 조회 (없으면 null 반환)
    public PostDTO findById(long id) throws SQLException {
        String sql = "SELECT id, title, content, author FROM post WHERE id = ?";
        Connection con = connect();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setLong(1, id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return toDTO(rs);
            }
            return null;
        } finally {
            close(con, pstmt, rs);
        }
    }

    // 제목, 내용, 작성자로 새 게시글 등록 (id는 DB에서 자동 생성), DTO로 자동 변환됨
    public void insert(PostDTO post) throws SQLException {
        String sql = "INSERT INTO post (title, content, author) VALUES (?, ?, ?)";
        Connection con = connect();
        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, post.getTitle());
            pstmt.setString(2, post.getContent());
            pstmt.setString(3, post.getAuthor());
            // INSERT, UPDATE, DELETE는 executeUpdate()
            pstmt.executeUpdate();
        } finally {
            close(con, pstmt, null);
        }
    }

    // 해당 번호의 게시글 수정 (한 건 수정되면 true 반환), DTO로 자동 변환됨
    public boolean update(PostDTO post) throws SQLException {
        String sql = "UPDATE post SET title = ?, content = ?, author = ? WHERE id = ?";
        Connection con = connect();
        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, post.getTitle());
            pstmt.setString(2, post.getContent());
            pstmt.setString(3, post.getAuthor());
            pstmt.setLong(4, post.getId());
            return pstmt.executeUpdate() == 1;
        } finally {
            close(con, pstmt, null);
        }
    }

    // 해당 번호의 게시글 삭제 (한 건 삭제되면 true 반환)
    public boolean delete(long id) throws SQLException {
        Connection con = connect();
        PreparedStatement pstmt = null;
        try {
            pstmt = con.prepareStatement("DELETE FROM post WHERE id = ?");
            pstmt.setLong(1, id);
            return pstmt.executeUpdate() == 1;
        } finally {
            close(con, pstmt, null);
        }
    }

    private void close(Connection con, PreparedStatement pstmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
        } catch (SQLException e) { e.printStackTrace(); }
        try {
            if (pstmt != null) pstmt.close();
        } catch (SQLException e) { e.printStackTrace(); }
        try {
            if (con != null) con.close();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    // DB 조회 결과 한 행을 PostDTO 객체로 변환
    private PostDTO toDTO(ResultSet rs) throws SQLException {
        PostDTO post = new PostDTO();
        post.setId(rs.getLong("id"));
        post.setTitle(rs.getString("title"));
        post.setContent(rs.getString("content"));
        post.setAuthor(rs.getString("author"));
        return post;
    }
}
