<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="게시글 상세" scope="page" />
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="UTF-8"><title>${pageScope.pageTitle}</title></head>
<body>
<%@ include file="header.jsp" %>
<h2><c:out value="${requestScope.post.title}" /></h2>
<p>번호: ${requestScope.post.id} / 작성자: <c:out value="${requestScope.post.author}" /></p>
<div style="white-space: pre-wrap"><c:out value="${requestScope.post.content}" /></div>
<hr>
<a href="${boardUrl}?action=edit&amp;id=${requestScope.post.id}">수정</a>
<form action="${boardUrl}" method="post">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" value="${requestScope.post.id}">
    <button type="submit">삭제</button>
</form>
</body>
</html>
