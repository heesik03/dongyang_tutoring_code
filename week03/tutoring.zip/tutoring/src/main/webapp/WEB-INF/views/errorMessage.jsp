<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="UTF-8"><title>오류</title></head>
<body>
<%@ include file="header.jsp" %>
<h2>요청을 처리하지 못했습니다.</h2>
<p><c:out value="${requestScope.error}" /></p>
</body>
</html>
