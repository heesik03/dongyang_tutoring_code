<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="editing" value="${not empty requestScope.post and requestScope.post.id > 0}" scope="page" />
<c:set var="pageTitle" value="${pageScope.editing ? '게시글 수정' : '게시글 작성'}" scope="page" />
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="UTF-8"><title>${pageScope.pageTitle}</title></head>
<body>
<%@ include file="header.jsp" %>
<h2>${pageScope.pageTitle}</h2>
<c:if test="${not empty requestScope.error}">
    <p><c:out value="${requestScope.error}" /></p>
</c:if>
<form action="${boardUrl}" method="post">
    <input type="hidden" name="action" value="${pageScope.editing ? 'update' : 'insert'}">
    <c:if test="${pageScope.editing}">
        <input type="hidden" name="id" value="${requestScope.post.id}">
    </c:if>
    <p><label for="title">제목</label><br>
        <input id="title" name="title" maxlength="255" required value="<c:out value='${requestScope.post.title}' />"></p>
    <p><label for="author">작성자</label><br>
        <input id="author" name="author" maxlength="100" required value="<c:out value='${not empty requestScope.post ? requestScope.post.author : sessionScope.lastAuthor}' />"></p>
    <p><label for="content">내용</label><br>
        <textarea id="content" name="content" rows="10" cols="60" required><c:out value="${requestScope.post.content}" /></textarea></p>
    <button type="submit">저장</button>
    <a href="${boardUrl}?action=list">취소</a>
</form>
</body>
</html>
