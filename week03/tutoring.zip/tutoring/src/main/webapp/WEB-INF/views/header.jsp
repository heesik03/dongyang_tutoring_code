<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:url var="boardUrl" value="/post.do" />
<h1><c:out value="${applicationScope.boardName}" /></h1>
<nav>
    <a href="${boardUrl}?action=list">목록</a>
    <a href="${boardUrl}?action=write">글쓰기</a>
</nav>
<p>마지막 작성자 (session): <c:out value="${sessionScope.lastAuthor}" default="없음" /></p>
<%-- redirect 후에도 session 메시지는 유지된다. 표시 후 제거한다. --%>
<c:if test="${not empty sessionScope.message}">
    <p><c:out value="${sessionScope.message}" /></p>
    <c:remove var="message" scope="session" />
</c:if>
<hr>
