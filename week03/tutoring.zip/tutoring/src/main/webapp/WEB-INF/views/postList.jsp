<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%-- page scope: 이 JSP 페이지에서 사용하는 제목 --%>
<c:set var="pageTitle" value="게시글 목록" scope="page" />
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="UTF-8"><title>${pageScope.pageTitle}</title></head>
<body>
<%@ include file="header.jsp" %>
<h2>${pageScope.pageTitle}</h2>
<table border="1">
    <tr><th>번호</th><th>제목</th><th>작성자</th></tr>
    <%-- request scope: Servlet에서 조회 후 forward로 전달한 목록 --%>
    <c:forEach items="${requestScope.postList}" var="post">
        <tr>
            <td><c:out value="${post.id}" /></td>
            <td><a href="${boardUrl}?action=view&amp;id=${post.id}"><c:out value="${post.title}" /></a></td>
            <td><c:out value="${post.author}" /></td>
        </tr>
    </c:forEach>
    <c:if test="${empty requestScope.postList}">
        <tr><td colspan="3">등록된 게시글이 없습니다.</td></tr>
    </c:if>
</table>
</body>
</html>
